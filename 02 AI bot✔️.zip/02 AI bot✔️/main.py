# Import PySimpleGUI for building the graphical user interface
import PySimpleGUI as sg

# Import LangChain's message type for sending human input
from langchain_core.messages import HumanMessage

# Import the OpenAI chat model (e.g., GPT) from LangChain
from langchain_openai import ChatOpenAI

# Import the @tool decorator to define tools usable by the agent
from langchain.tools import tool

# Import a utility to create a ReAct-based agent from LangGraph
from langgraph.prebuilt import create_react_agent

# Load environment variables from a .env file (for the OpenAI API key)
from dotenv import load_dotenv

# Used to run background tasks so GUI doesn’t freeze
import threading

# Load environment variables (like OPENAI_API_KEY) into the environment
load_dotenv()

# ------------------------ TOOL DEFINITIONS ------------------------

# Define a simple calculator tool for addition
@tool
def calculator(a: float, b: float) -> str:
    """Useful for performing basic arithmetic calculations with numbers"""
    return f"The sum of {a} and {b} is {a + b}"

# Define a greeting tool to say hello to a user
@tool
def say_hello(name: str) -> str:
    """Useful for greeting a user"""
    return f"Hello {name}, I hope you are well today"

# ------------------------ AGENT SETUP ------------------------

# Create the OpenAI chat model with temperature 0 (deterministic output)
model = ChatOpenAI(temperature=0)

# List of tools the agent can use
tools = [calculator, say_hello]

# Create the LangChain agent that can use the tools and language model
agent_executor = create_react_agent(model, tools)

# ------------------------ GUI SETUP ------------------------

# Set GUI color theme (DarkBlack, SystemDefault, etc.)
sg.theme('DarkBlack')

# Define the layout of the GUI window
layout = [
    # Chat history display (multiline text box, not editable)
    [sg.Multiline(size=(80, 20), key='-CHAT-', disabled=True, autoscroll=True)],

    # Input box for user messages and Send/Quit buttons
    [sg.InputText(key='-INPUT-', size=(70, 1)), sg.Button('Send', bind_return_key=True), sg.Button('Quit')]
]

# Create the GUI window with the defined layout
window = sg.Window('Jarvis AI Assistant', layout, finalize=True)

# Shortcut to the chat display element for easier updates
chat_box = window['-CHAT-']

# ------------------------ HELPER FUNCTIONS ------------------------

# Function to display any message in the chat window
def display_message(text):
    chat_box.update(chat_box.get() + text + '\n')  # Append new text

# Function to handle user input and stream agent responses
def process_input(user_input):
    display_message(f'\nYou: {user_input}')  # Show user input
    display_message('\nJarvis: ')  # Prefix for agent reply

    try:
        # Stream the agent's response in real-time
        for chunk in agent_executor.stream({"messages": [HumanMessage(content=user_input)]}):
            if "agent" in chunk and "messages" in chunk["agent"]:
                for message in chunk["agent"]["messages"]:
                    # Send agent response back to GUI thread
                    window.write_event_value('-RESPONSE-', message.content)
    except Exception as e:
        # Display error if agent fails
        window.write_event_value('-RESPONSE-', f"Error: {e}")

# ------------------------ GUI EVENT LOOP ------------------------

# Start the main GUI event loop
while True:
    # Wait for events (like button press or message from background thread)
    event, values = window.read()

    # Handle window close or Quit button
    if event in (sg.WIN_CLOSED, 'Quit'):
        break

    # If Send is clicked or Enter is pressed
    if event == 'Send':
        user_input = values['-INPUT-'].strip()  # Get user input
        if user_input:
            window['-INPUT-'].update('')  # Clear input field
            # Start background thread to avoid freezing the GUI
            threading.Thread(target=process_input, args=(user_input,), daemon=True).start()

    # If response is received from the agent thread
    elif event == '-RESPONSE-':
        display_message(values['-RESPONSE-'])  # Show it in the chat

# Close the GUI window when the loop ends
window.close()
